# Skylink LiveTV CZ/SK

Plugin generuje playlist a EPG pre službu Skylink LiveTV, pre použitie v IPTV Simple Client.

Ako video doplnok zobrazuje aj archív služby Skylink.

V prípade nefunkčnosti generovania playlistu a epg (napr. z dôvodu chýbajúcich práv na zápis) je možné zobraziť Live stanice aj vo video doplnku.

Od verzie 1.3.0 sa zobrazuje primárne ako video doplnok.

Podpora je k dispozíci na webe [XBMC-Kodi.cz](https://www.xbmc-kodi.cz/prispevek-skylink-livetv-addon)